#!/usr/bin/env python3
"""Write the Arclight specimen page with the three TTFs embedded as data URIs."""
import base64, json, os, sys
from build_arclight import G

dist = sys.argv[1] if len(sys.argv) > 1 else "dist"
out = sys.argv[2] if len(sys.argv) > 2 else "arclight-typeface.html"

def b64(style):
    with open(os.path.join(dist, f"Arclight-{style}.ttf"), "rb") as f:
        return base64.b64encode(f.read()).decode()

faces, links = [], []
for style, wght in (("Light", 300), ("Regular", 400), ("Bold", 700)):
    data = b64(style)
    faces.append(f"""@font-face{{font-family:Arclight;font-weight:{wght};font-style:normal;
  src:url(data:font/ttf;base64,{data}) format("truetype");font-display:block}}""")
    links.append(f'<a class="dl" download="Arclight-{style}.ttf" '
                 f'href="data:font/ttf;base64,{data}">Arclight-{style}.ttf</a>')

HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Arclight — a monoline arc typeface</title>
<style>
__FACES__
:root{
  --navy:#0A1526; --navy-2:#122139; --off:#F0EDE6; --denim:#4A7BB0; --red:#E03C31;
  --line:rgba(240,237,230,.14);
}
*{box-sizing:border-box}
html,body{margin:0;background:var(--navy);color:var(--off);
  font-family:"Helvetica Neue",Helvetica,Arial,sans-serif;-webkit-font-smoothing:antialiased}
body{padding:clamp(20px,4vw,56px);max-width:1180px;margin:0 auto}

header{border-bottom:1px solid var(--line);padding-bottom:26px;margin-bottom:34px}
h1{font:400 46px/1 Arclight,sans-serif;letter-spacing:.06em;margin:0 0 12px}
header p{margin:0;font-size:14px;line-height:1.6;color:rgba(240,237,230,.62);max-width:62ch}
header .rule{display:block;width:30px;height:2px;background:var(--red);margin-bottom:18px}

.stage{background:var(--navy-2);border:1px solid var(--line);border-radius:2px;
  padding:34px 24px;min-height:190px;display:flex;align-items:center;overflow:hidden}
#type{font-family:Arclight,sans-serif;font-size:96px;line-height:1.15;letter-spacing:.05em;
  color:var(--off);width:100%;outline:none;word-break:break-word}
#type:focus{caret-color:var(--red)}

.controls{display:flex;flex-wrap:wrap;gap:20px 26px;align-items:center;margin:18px 0 56px}
label{font-size:11px;letter-spacing:.14em;color:rgba(240,237,230,.5);display:flex;align-items:center;gap:10px}
input[type=range]{accent-color:var(--denim);width:110px}
.seg{display:flex;border:1px solid var(--line);border-radius:2px;overflow:hidden}
.seg button{background:none;border:0;color:rgba(240,237,230,.55);font:400 11px/1 inherit;
  letter-spacing:.14em;padding:9px 13px;cursor:pointer}
.seg button[aria-pressed=true]{background:var(--denim);color:var(--navy)}
.sw{width:20px;height:20px;border-radius:50%;border:1px solid var(--line);cursor:pointer;padding:0}
.sw[aria-pressed=true]{box-shadow:0 0 0 2px var(--navy),0 0 0 3px var(--off)}
button:focus-visible,a:focus-visible,input:focus-visible,[contenteditable]:focus-visible{
  outline:2px solid var(--denim);outline-offset:3px}

h2{font-size:11px;font-weight:600;letter-spacing:.2em;color:rgba(240,237,230,.45);
  margin:0 0 16px;padding-bottom:8px;border-bottom:1px solid var(--line)}
.wline{font-family:Arclight,sans-serif;font-size:clamp(28px,5.4vw,58px);letter-spacing:.04em;
  margin:0 0 6px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.wmeta{font-size:11px;letter-spacing:.14em;color:rgba(240,237,230,.35);margin:0 0 26px}
.para{font-family:Arclight,sans-serif;font-size:19px;line-height:1.75;letter-spacing:.03em;
  max-width:56ch;color:rgba(240,237,230,.82);margin:0 0 46px}

.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(92px,1fr));gap:2px;margin-bottom:44px}
.cell{background:var(--navy-2);aspect-ratio:1/1.1;display:flex;align-items:center;justify-content:center;position:relative}
.cell:hover{background:#16294a}
.cell svg{width:76%;height:76%}
.cell b{position:absolute;left:7px;top:6px;font-size:9px;font-weight:400;
  color:rgba(240,237,230,.28);letter-spacing:.08em}
.guides line{stroke:rgba(74,123,176,.28);stroke-width:1.5}

.files{display:flex;flex-wrap:wrap;gap:10px;margin-bottom:26px}
.dl{background:none;border:1px solid var(--line);color:var(--off);text-decoration:none;
  font:400 12px/1 inherit;letter-spacing:.06em;padding:11px 15px;border-radius:2px;cursor:pointer}
.dl:hover{border-color:var(--denim);color:var(--denim)}
pre{background:var(--navy-2);border:1px solid var(--line);border-left:2px solid var(--red);
  padding:18px 20px;overflow-x:auto;font:400 12.5px/1.7 ui-monospace,Menlo,Consolas,monospace;
  color:rgba(240,237,230,.8);margin:0 0 30px}
footer{border-top:1px solid var(--line);padding-top:22px;font-size:12px;line-height:1.7;
  color:rgba(240,237,230,.45);max-width:70ch}
@media (prefers-reduced-motion:no-preference){.cell{transition:background .15s ease}}
</style>
</head>
<body>

<header>
  <span class="rule"></span>
  <h1>Arclight</h1>
  <p>A monoline display face built from arcs and straights only — no corners, no fills, and the fewest strokes that still read. Three weights, 91 glyphs. Type in the box to set it.</p>
</header>

<div class="stage"><div id="type" contenteditable="true" spellcheck="false"
     aria-label="Editable specimen text">Arclight 2049</div></div>

<div class="controls">
  <label>SIZE <input id="size" type="range" min="28" max="200" value="96"></label>
  <label>TRACK <input id="track" type="range" min="-4" max="30" value="5"></label>
  <div class="seg" id="wsel">
    <button data-w="300">LIGHT</button>
    <button data-w="400" aria-pressed="true">REGULAR</button>
    <button data-w="700">BOLD</button>
  </div>
  <div style="display:flex;gap:8px">
    <button class="sw" style="background:#F0EDE6" data-c="#F0EDE6" aria-label="Off-white" aria-pressed="true"></button>
    <button class="sw" style="background:#4A7BB0" data-c="#4A7BB0" aria-label="Denim blue" aria-pressed="false"></button>
    <button class="sw" style="background:#E03C31" data-c="#E03C31" aria-label="Red" aria-pressed="false"></button>
  </div>
</div>

<h2>Weights</h2>
<p class="wline" style="font-weight:300">Orbital transit, gate 14</p>
<p class="wmeta">LIGHT · 300</p>
<p class="wline" style="font-weight:400">Orbital transit, gate 14</p>
<p class="wmeta">REGULAR · 400</p>
<p class="wline" style="font-weight:700">Orbital transit, gate 14</p>
<p class="wmeta">BOLD · 700</p>

<h2>In text</h2>
<p class="para">Every letter is drawn as a single centre line and expanded to an outline at build
time, so the face keeps one stroke thickness everywhere: no thick-and-thin, no corners, no
counters cut by hand. The round terminals come from the stroke itself. Set it large — it is a
display face, and it gets quiet below 16 px.</p>

<h2>Construction</h2>
<p class="para" style="font-family:inherit;font-size:14px;color:rgba(240,237,230,.55);margin-bottom:22px">
Centre lines on the 200-unit design grid. Blue rules mark the x-height and the baseline.</p>
<div class="grid" id="gUp"></div>
<div class="grid" id="gLo"></div>
<div class="grid" id="gNu"></div>

<h2>Install and use</h2>
<div class="files">__LINKS__</div>
<pre>@font-face {
  font-family: "Arclight";
  src: url("Arclight-Regular.woff2") format("woff2"),
       url("Arclight-Regular.ttf")   format("truetype");
  font-weight: 400;
  font-display: swap;
}
/* repeat for 300 (Light) and 700 (Bold) */

h1 { font-family: "Arclight", sans-serif; letter-spacing: .05em; }</pre>

<footer>
Metrics: 1000 units per em, cap height 704, x-height 384, descender −256, sidebearings set on
the ink. To install locally, double-click a .ttf. To ship on the web, use the .woff2 files —
they are a third of the size. Rebuild any weight by changing the stroke width in
build_arclight.py and running it again.
</footer>

<script>
const G = __GLYPHS__;
const type = document.getElementById("type");
document.getElementById("size").addEventListener("input", e => type.style.fontSize = e.target.value + "px");
document.getElementById("track").addEventListener("input", e => type.style.letterSpacing = e.target.value/100 + "em");
document.querySelectorAll("#wsel button").forEach(b => b.addEventListener("click", () => {
  document.querySelectorAll("#wsel button").forEach(o => o.setAttribute("aria-pressed", o === b));
  type.style.fontWeight = b.dataset.w;
}));
document.querySelectorAll(".sw").forEach(b => b.addEventListener("click", () => {
  document.querySelectorAll(".sw").forEach(o => o.setAttribute("aria-pressed", o === b));
  type.style.color = b.dataset.c;
}));

function cell(ch){
  const g = G[ch], w = g[1];
  const label = ch === " " ? "sp" : ch.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;");
  return `<div class="cell"><b>${label}</b>
    <svg viewBox="-14 6 ${w+28} 190" aria-label="glyph ${label}">
      <g class="guides"><line x1="-14" y1="70" x2="${w+14}" y2="70"/><line x1="-14" y1="130" x2="${w+14}" y2="130"/></g>
      <path d="${g[0]}" fill="none" stroke="#F0EDE6" stroke-width="7" stroke-linecap="round" stroke-linejoin="round"/>
    </svg></div>`;
}
const up = "ABCDEFGHIJKLMNOPQRSTUVWXYZ", lo = up.toLowerCase(), nu = "0123456789.,:;!?-'\\"/\\\\()[]+=*#&@%$<>";
document.getElementById("gUp").innerHTML = [...up].map(cell).join("");
document.getElementById("gLo").innerHTML = [...lo].map(cell).join("");
document.getElementById("gNu").innerHTML = [...nu].map(cell).join("");
</script>
</body>
</html>
"""

html = (HTML.replace("__FACES__", "\n".join(faces))
            .replace("__LINKS__", "\n    ".join(links))
            .replace("__GLYPHS__", json.dumps(G, ensure_ascii=False)))
with open(out, "w") as f:
    f.write(html)
print(f"{out}: {os.path.getsize(out)/1024:.0f} KB")
